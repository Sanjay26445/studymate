from django import forms
from .models import Profile, Goal, Doubt

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['name', 'personal_info']

class GoalForm(forms.ModelForm):
    class Meta:
        model = Goal
        fields = ['goal_text']

class DoubtForm(forms.ModelForm):
    class Meta:
        model = Doubt
        fields = ['question']