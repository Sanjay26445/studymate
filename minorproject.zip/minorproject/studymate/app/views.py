from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from .models import Profile, Goal, Doubt
from .forms import ProfileForm, GoalForm, DoubtForm

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user)
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

def dashboard(request):
    goals = Goal.objects.filter(user=request.user)
    return render(request, 'dashboard.html', {'goals': goals})

def ask_doubt(request):
    if request.method == 'POST':
        form = DoubtForm(request.POST)
        if form.is_valid():
            doubt = form.save(commit=False)
            doubt.user = request.user
            doubt.save()
            return redirect('dashboard')
    else:
        form = DoubtForm()
    return render(request, 'ask_doubt.html', {'form': form})

def answer_doubt(request):
    doubts = Doubt.objects.all()
    return render(request, 'answer_doubt.html', {'doubts': doubts})

def history(request):
    doubts = Doubt.objects.filter(user=request.user)
    return render(request, 'history.html', {'doubts': doubts})

def profile(request):
    profile = Profile.objects.get(user=request.user)
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = ProfileForm(instance=profile)
    return render(request, 'profile.html', {'form': form})