from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('ask-doubt/', views.ask_doubt, name='ask_doubt'),
    path('answer-doubt/', views.answer_doubt, name='answer_doubt'),
    path('history/', views.history, name='history'),
    path('profile/', views.profile, name='profile'),
]