from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    personal_info = models.TextField()

class Goal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    goal_text = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)

class Doubt(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.TextField()
    answer = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    unique_id = models.CharField(max_length=10, unique=True)