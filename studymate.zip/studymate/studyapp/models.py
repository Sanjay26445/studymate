from django.db import models
from django.contrib.auth.models import User

class PersonalDetails(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=255)
    date_of_birth = models.DateField()
    college_name = models.CharField(max_length=255)
    education_qualification = models.CharField(max_length=255)
    teacher_id = models.CharField(max_length=100, unique=True)
    profile_image = models.ImageField(upload_to='profile_images/', null=True, blank=True)  # Add this field

    def __str__(self):
        return self.full_name
    
class Question(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    domain = models.CharField(max_length=255)
    question_text = models.TextField()
    upvotes = models.IntegerField(default=0)
    downvotes = models.IntegerField(default=0)
    voters = models.ManyToManyField(User, through='Vote', related_name='question_votes')
    timestamp = models.DateTimeField(auto_now_add=True)  # ✅ Add timestamp field

    def update_votes(self):
        """Update upvotes and downvotes count"""
        self.upvotes = self.votes.filter(vote_type='upvote').count()
        self.downvotes = self.votes.filter(vote_type='downvote').count()
        self.save()

class Vote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='votes')
    vote_type = models.CharField(max_length=10, choices=[('upvote', 'Upvote'), ('downvote', 'Downvote')])

    class Meta:
        unique_together = ('user', 'question')  # Ensures one vote per question per user



class Solution(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="solutions")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    solution_text = models.TextField()
    solution_file = models.FileField(upload_to="solutions/", blank=True, null=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    upvotes = models.IntegerField(default=0)
    downvotes = models.IntegerField(default=0)

class SolutionVote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    solution = models.ForeignKey(Solution, on_delete=models.CASCADE)
    vote_type = models.CharField(max_length=10, choices=[('upvote', 'Upvote'), ('downvote', 'Downvote')])
    
    class Meta:
        unique_together = ('user', 'solution')  # Ensure each user votes only once per solution


class StudyGoal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Associate with a user
    goal_text = models.TextField()
    target_date = models.DateField()
    completed = models.BooleanField(default=False)

    def __str__(self):
        return self.goal_text
