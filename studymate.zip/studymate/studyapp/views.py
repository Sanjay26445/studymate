from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages

# Home Page
def home(request):
    return render(request, 'home.html')

# Dashboard (Only for logged-in users)
def dashboard(request):
    if not request.user.is_authenticated:
        messages.warning(request, "You must be logged in to access the dashboard.")
        return redirect('user_login')
    return render(request, 'dashboard.html')

# User Signup
def user_signup(request):
    if request.method == "POST":
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip()
        password1 = request.POST.get('password', '')
        password2 = request.POST.get('confirm_password', '')

        # Basic Validations
        if not username or not email or not password1 or not password2:
            messages.error(request, "All fields are required!")
            return redirect('signup')

        if password1 != password2:
            messages.error(request, "Passwords do not match!")
            return redirect('signup')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect('signup')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
            return redirect('signup')

        # Creating User
        user = User.objects.create_user(username=username, email=email, password=password1)
        user.save()
        # messages.success(request, "Account created successfully! You can now log in.")
        # return redirect('user_login')
        login(request, user)  # Log in user immediately after signup

        return redirect('personal_details')  # Redirect to personal details page

    return render(request, 'signup.html')

# User Login
def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        if not username or not password:
            messages.error(request, "Both fields are required!")
            return redirect('user_login')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, f"Welcome, {username}! You are now logged in.")
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid credentials! Please try again.")
            return redirect('user_login')

    return render(request, 'login.html')

# User Logout
def user_logout(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('home')


from django.contrib.auth.decorators import login_required
from .models import PersonalDetails


def personal_details(request):
    if request.method == "POST":
        full_name = request.POST.get('full_name', '').strip()
        date_of_birth = request.POST.get('date_of_birth', '').strip()
        college_name = request.POST.get('college_name', '').strip()
        education_qualification = request.POST.get('education_qualification', '').strip()
        teacher_id = request.POST.get('teacher_id', '').strip()

        # Ensure no field is empty
        if not all([full_name, date_of_birth, college_name, education_qualification,]):
            messages.error(request, "All fields are required!")
            return redirect('personal_details')

        # Save details
        PersonalDetails.objects.create(
            user=request.user,
            full_name=full_name,
            date_of_birth=date_of_birth,
            college_name=college_name,
            education_qualification=education_qualification,
            teacher_id=teacher_id,
        )

        messages.success(request, "Details saved successfully! Please log in.")
        return redirect('user_login')  # Redirect to login after saving details

    return render(request, 'personal_details.html')

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import PersonalDetails

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import PersonalDetails
from django.core.files.storage import default_storage

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import PersonalDetails
from django.core.files.storage import default_storage

@login_required
def profile(request):
    personal_details = PersonalDetails.objects.get(user=request.user)

    if request.method == "POST":
        # Handle profile image upload
        if 'profile_image' in request.FILES:
            # Delete the old image if it exists
            if personal_details.profile_image:
                default_storage.delete(personal_details.profile_image.path)
            # Save the new image
            personal_details.profile_image = request.FILES['profile_image']
            personal_details.save()
            return redirect('profile')

    context = {
        'user': request.user,
        'personaldetails': personal_details,
    }
    return render(request, 'profile.html', context)



from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Question

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Question

def ask_question(request):
    if request.method == "POST":
        domain = request.POST.get('domain')
        question_text = request.POST.get('questionText')

        # Validate input
        if not domain or not question_text:
            messages.error(request, "Please fill out all fields.")
            return redirect('ask_question')

        # Save the question to the database
        Question.objects.create(
            user=request.user,
            domain=domain,
            question_text=question_text,
        )
        messages.success(request, "Question submitted successfully!")
        return redirect('dashboard')  # Redirect to the same page to display the message

    return render(request, 'ask_question.html')

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Question

@login_required
def view_doubts(request):
    questions = Question.objects.all().order_by('-timestamp')  # Fetch all questions, ordered by latest first
    context = {
        'questions': questions,
    }
    return render(request, 'view_doubts.html', context)

from django.shortcuts import get_object_or_404, redirect
from django.http import JsonResponse
from .models import Question, Vote
from django.contrib.auth.decorators import login_required

@login_required
def vote_question(request):
    if request.method == "POST":
        question_id = request.POST.get("question_id")
        vote_type = request.POST.get("vote_type")
        question = get_object_or_404(Question, id=question_id)

        # Check if user already voted
        existing_vote = Vote.objects.filter(user=request.user, question=question).first()

        if existing_vote:
            # If the same vote type is clicked, remove the vote
            if existing_vote.vote_type == vote_type:
                existing_vote.delete()
            else:
                # Change vote type (upvote <-> downvote)
                existing_vote.vote_type = vote_type
                existing_vote.save()
        else:
            # New vote
            Vote.objects.create(user=request.user, question=question, vote_type=vote_type)

        # Update vote counts
        question.update_votes()

        return JsonResponse({"upvotes": question.upvotes, "downvotes": question.downvotes})
    
    return JsonResponse({"error": "Invalid request"}, status=400)

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from .models import Question, Solution

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Question, Solution

@login_required
def solve_doubt(request, question_id):
    question = get_object_or_404(Question, id=question_id)

    if request.method == "POST":
        solution_text = request.POST.get('solution_text')
        solution_file = request.FILES.get('solution_file')

        solution = Solution.objects.create(
            question=question,
            user=request.user,
            solution_text=solution_text
        )

        if solution_file:
            solution.solution_file = solution_file
            solution.save()

        return redirect('solve_doubt', question_id=question.id)

    return render(request, 'solve_doubt.html', {'question': question})


from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Question, Solution
from .forms import SolutionForm  # Create a form for submitting solutions


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Question, Solution
from django.contrib.auth.decorators import login_required

@login_required
def submit_solution(request, question_id):
    question = get_object_or_404(Question, id=question_id)

    if request.method == "POST":
        solution_text = request.POST.get('solution_text')
        solution_file = request.FILES.get('solution_file', None)

        if not solution_text:
            messages.error(request, "Solution text cannot be empty.")
            return redirect('question_detail', question_id=question.id)

        Solution.objects.create(
            question=question,
            user=request.user,
            solution_text=solution_text,
            solution_file=solution_file
        )

        messages.success(request, "Solution submitted successfully!")
        return redirect('view_doubts')

    return redirect('view_doubts')


from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from .models import Question, Solution

def view_solutions(request, question_id):
    """Displays all solutions for a given question"""
    question = get_object_or_404(Question, id=question_id)
    solutions = Solution.objects.filter(question=question).order_by('submitted_at')

    return render(request, 'view-solutions.html', {
        'question': question,
        'solutions': solutions
    })

from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Solution, SolutionVote

def vote_solution(request):
    """Handles upvote/downvote functionality with toggle feature"""
    if request.method == "POST":
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'You must be logged in to vote'}, status=403)

        solution_id = request.POST.get('solution_id')
        vote_type = request.POST.get('vote_type')

        solution = get_object_or_404(Solution, id=solution_id)
        existing_vote = SolutionVote.objects.filter(user=request.user, solution=solution).first()

        if existing_vote:
            if existing_vote.vote_type == vote_type:
                # Remove vote if the user clicks the same button again
                existing_vote.delete()
                if vote_type == "upvote":
                    solution.upvotes -= 1
                else:
                    solution.downvotes -= 1
                solution.save()
                return JsonResponse({'status': 'removed', 'upvotes': solution.upvotes, 'downvotes': solution.downvotes})
            else:
                # Change vote from upvote to downvote or vice versa
                existing_vote.vote_type = vote_type
                existing_vote.save()
                if vote_type == "upvote":
                    solution.upvotes += 1
                    solution.downvotes -= 1
                else:
                    solution.downvotes += 1
                    solution.upvotes -= 1
        else:
            # New vote
            SolutionVote.objects.create(user=request.user, solution=solution, vote_type=vote_type)
            if vote_type == "upvote":
                solution.upvotes += 1
            else:
                solution.downvotes += 1

        solution.save()
        return JsonResponse({'status': vote_type, 'upvotes': solution.upvotes, 'downvotes': solution.downvotes})

    return JsonResponse({'error': 'Invalid request'}, status=400)


def help(request):
    return render(request, 'help.html')

from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import StudyGoal
from django.contrib.auth.decorators import login_required
import json

@login_required
def save_goal(request):
    if request.method == "POST":
        data = json.loads(request.body)
        goal_text = data.get("goal_text")
        target_date = data.get("target_date")

        if goal_text and target_date:
            StudyGoal.objects.create(user=request.user, goal_text=goal_text, target_date=target_date)
            return JsonResponse({"message": "Goal saved successfully!"}, status=201)

    return JsonResponse({"error": "Invalid request"}, status=400)

from .models import StudyGoal  # Assuming StudyGoal is a model
@login_required
def get_goals(request):
    goals = StudyGoal.objects.filter(user=request.user)
    goals_data = [
        {"id": goal.id, "goal_text": goal.goal_text, "target_date": goal.target_date.strftime("%Y-%m-%d"), "completed": goal.completed}
        for goal in goals
    ]
    return JsonResponse(goals_data, safe=False)

def studygoals(request):
    goals = StudyGoal.objects.all()
    return render(request, 'studygoals.html', {'goals': goals})

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Question, Solution

@login_required
def history_view(request):
    user_questions = Question.objects.filter(user=request.user).order_by('-timestamp')
    user_solutions = Solution.objects.filter(user=request.user).order_by('-submitted_at')

    context = {
        'user_questions': user_questions,
        'user_solutions': user_solutions,
    }
    return render(request, 'history.html', context)
