from django import forms
from django.contrib.auth.models import User
from .models import PersonalDetails

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']  # Removed 'confirm_password'

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            self.add_error("confirm_password", "Passwords do not match!")

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])  # Hash the password
        if commit:
            user.save()
        return user


class PersonalDetailsForm(forms.ModelForm):
    class Meta:
        model = PersonalDetails
        fields = ['full_name', 'date_of_birth', 'college_name', 'education_qualification', 'teacher_id']


from django import forms
from .models import Solution

class SolutionForm(forms.ModelForm):
    class Meta:
        model = Solution
        fields = ["solution_text", "solution_file"]
