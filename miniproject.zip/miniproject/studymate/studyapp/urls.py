# studyapp/urls.py
from django.urls import path
from .views import mainpage
from . import views

urlpatterns = [
    path('', mainpage, name='login'),  # Main page route

]
